# Zìyóu (自由) — Site Lock

A browser extension that blocks distracting sites, locks itself against
early bailouts once you set a timer, and shows a full-screen video +
rotating quote instead of the site you tried to open.

## What it does

- **Custom blocks** — type in any domain to block it.
- **Categories** — one-click toggle for Social Media, Video & Streaming,
  Gaming, Shopping, News.
- **Always-blocked** — Adult and Gambling categories are on from the moment
  you install it and cannot be turned off from the UI (matched by both a
  domain list and keyword fallback, so it holds up against sites not on the
  list).
- **Timed locks** — block a site *or* a whole category with a duration. Once
  set, the "Remove" / "off" control is disabled and shows a live countdown
  until the timer runs out — there's no early-unlock button anywhere in the UI.
- **Block page** — full-bleed looping video background (your own `vid1.mp4`
  … `vidN.mp4` files) with a translucent quote overlaid so it never fights
  the video for attention. A new quote and a new video are picked at random
  every time the page loads. Quotes mix plain "don't waste this" lines with
  Islamic reminders about time (Surah Al-'Asr, a few well-known hadith on
  time and health, etc.) — all editable in `quotes.js`.

## Install it locally (Chrome / Edge / Brave)

1. Unzip the folder.
2. Drop your looping background videos into `media/`, named `vid1.mp4`,
   `vid2.mp4`, `vid3.mp4`, `vid4.mp4` (see the txt file in that folder).
3. Go to `chrome://extensions` (or `edge://extensions`).
4. Turn on **Developer mode** (top right).
5. Click **Load unpacked** and select the `ziyou-extension` folder.
6. Pin the extension and open the popup to set up your blocks.

## Install it locally (Firefox)

Firefox needs a couple of manifest tweaks (it wants `background.scripts`
instead of a service worker, and a `browser_specific_settings` id). If you
want to run it there day-to-day rather than just testing, say so and I'll
give you a Firefox-flavored copy — porting the logic itself is trivial.

For a quick test right now: go to `about:debugging#/runtime/this-firefox` →
**Load Temporary Add-on** → pick `manifest.json`. It'll mostly work as-is
since Firefox does accept a service-worker-style background in recent
versions, but treat it as a test, not your daily setup.

## Honest limitation

No extension can stop you from going to `chrome://extensions` and disabling
or removing itself — that's a browser-level permission Chrome deliberately
doesn't hand out to extensions, for the same reason no app can stop you
uninstalling it. If you want a harder floor than "the extension won't let
me," options that go further:
- A friend/partner holds the password to a Chrome profile you don't normally
  use for admin tasks, so disabling the extension isn't a one-click thing.
- OS-level tools (Screen Time on Mac, Family Safety on Windows) that block
  at the network/DNS level instead of the browser level.

## Publishing it (so it installs like a normal extension, not "unpacked")

- **Chrome Web Store** — developer.chrome.com/docs/webstore, one-time $5
  registration fee, then upload a zip of this folder. Review usually takes a
  few days. You can also publish as "unlisted" (installable only via direct
  link, not searchable) if you just want it on your own devices/accounts
  without going fully public.
- **Microsoft Edge Add-ons** — partner.microsoft.com/dashboard/microsoftedge,
  free to register, similar review flow, and it also shows up for Chrome
  users who install it manually since Edge's store accepts the same
  manifest format.
- **Firefox Add-ons (AMO)** — addons.mozilla.org/developers, free, needs the
  Firefox manifest tweaks mentioned above.

For personal use across your own devices, "unlisted" on the Chrome Web
Store (or just re-loading the unpacked folder via a synced Google Drive
copy) is usually enough — you don't need to go through public review unless
you want other people finding and installing it.

## Files

```
manifest.json     — extension config
background.js     — checks every navigation against your block list
domains.js        — category + always-blocked domain/keyword lists
quotes.js         — the rotating quotes (edit freely)
blocked.html/css/js — the page shown instead of a blocked site
popup.html/css/js — the UI for managing blocks
media/            — put your vid1.mp4 ... vidN.mp4 here
icons/            — toolbar icon
```
