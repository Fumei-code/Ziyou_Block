importScripts("domains.js");

const DEFAULT_STATE = {
  customBlocks: [],       // [{ id, pattern, addedAt, lockUntil|null }]
  categoriesOn: {},        // { socialMedia: true/false, ... } — optional categories only
  categoryLockUntil: {},   // { socialMedia: timestamp|null } — lock on a whole category
  videoCount: 4
};

async function getState() {
  const stored = await chrome.storage.local.get(Object.keys(DEFAULT_STATE));
  return { ...DEFAULT_STATE, ...stored };
}

function normalizeHost(url) {
  try {
    const u = new URL(url);
    return u.hostname.replace(/^www\./, "").toLowerCase();
  } catch (e) {
    return "";
  }
}

function hostMatchesDomain(host, domain) {
  return host === domain || host.endsWith("." + domain);
}

function hostMatchesKeyword(host, keyword) {
  return host.includes(keyword);
}

function hostMatchesPattern(host, pattern) {
  // pattern may be a bare domain ("reddit.com") or something the user pasted
  // with a scheme/path — normalize it the same way.
  let p = pattern.trim().toLowerCase();
  p = p.replace(/^https?:\/\//, "").split("/")[0].replace(/^www\./, "");
  if (!p) return false;
  return hostMatchesDomain(host, p);
}

// Returns null if not blocked, or an object describing why + when (if ever) it unlocks.
async function checkBlocked(host) {
  if (!host) return null;
  const now = Date.now();

  // 1. Always-blocked categories — no toggle, no unlock, ever.
  for (const [cat, def] of Object.entries(ALWAYS_BLOCKED)) {
    if (def.domains.some(d => hostMatchesDomain(host, d))) {
      return { blocked: true, permanent: true, reason: `${cat} sites are always blocked` };
    }
    if (def.keywords.some(k => hostMatchesKeyword(host, k))) {
      return { blocked: true, permanent: true, reason: `${cat} sites are always blocked` };
    }
  }

  const state = await getState();

  // 2. Optional categories the user turned on.
  for (const [cat, def] of Object.entries(CATEGORIES)) {
    if (state.categoriesOn[cat] && def.domains.some(d => hostMatchesDomain(host, d))) {
      const lockUntil = state.categoryLockUntil[cat] || null;
      if (lockUntil && lockUntil > now) {
        return { blocked: true, permanent: false, unlockAt: lockUntil, reason: `${def.label} is locked` };
      }
      return { blocked: true, permanent: false, unlockAt: null, reason: `${def.label} is blocked` };
    }
  }

  // 3. Custom user-added sites.
  for (const entry of state.customBlocks) {
    if (hostMatchesPattern(host, entry.pattern)) {
      if (entry.lockUntil && entry.lockUntil > now) {
        return { blocked: true, permanent: false, unlockAt: entry.lockUntil, reason: "This site is locked" };
      }
      return { blocked: true, permanent: false, unlockAt: null, reason: "This site is blocked" };
    }
  }

  return null;
}

chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  if (details.frameId !== 0) return; // main frame only
  const host = normalizeHost(details.url);
  if (!host) return;

  const result = await checkBlocked(host);
  if (result && result.blocked) {
    const blockedUrl = chrome.runtime.getURL("blocked.html") +
      "?site=" + encodeURIComponent(host) +
      "&reason=" + encodeURIComponent(result.reason || "") +
      (result.unlockAt ? "&unlockAt=" + result.unlockAt : "");
    chrome.tabs.update(details.tabId, { url: blockedUrl });
  }
});

// Periodic cleanup: drop expired locks so the popup UI reflects reality
// even if the user hasn't reopened it since the timer ran out.
chrome.alarms.create("ziyou-cleanup", { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== "ziyou-cleanup") return;
  const state = await getState();
  const now = Date.now();
  let changed = false;

  for (const cat of Object.keys(state.categoryLockUntil)) {
    if (state.categoryLockUntil[cat] && state.categoryLockUntil[cat] <= now) {
      state.categoryLockUntil[cat] = null;
      changed = true;
    }
  }
  // Expired timed custom blocks become ordinary (removable) blocks, not auto-deleted,
  // since "timer ran out" means "you may now remove it", not "it vanishes".
  for (const entry of state.customBlocks) {
    if (entry.lockUntil && entry.lockUntil <= now) {
      entry.lockUntil = null;
      changed = true;
    }
  }

  if (changed) {
    await chrome.storage.local.set({
      categoryLockUntil: state.categoryLockUntil,
      customBlocks: state.customBlocks
    });
  }
});

chrome.runtime.onInstalled.addListener(async () => {
  const current = await chrome.storage.local.get(Object.keys(DEFAULT_STATE));
  const merged = { ...DEFAULT_STATE, ...current };
  await chrome.storage.local.set(merged);
});
