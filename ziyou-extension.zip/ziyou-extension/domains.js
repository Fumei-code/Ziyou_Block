// domains.js
// Shared, loaded by both the background service worker (importScripts)
// and any UI page that needs to show category contents.

// These two categories are always on and cannot be disabled from the UI.
// Both a domain list AND a keyword fallback are used, since new adult/gambling
// sites appear constantly and a fixed domain list alone goes stale fast.
const ALWAYS_BLOCKED = {
  adult: {
    domains: [
      "pornhub.com", "xvideos.com", "xnxx.com", "redtube.com", "xhamster.com",
      "youporn.com", "spankbang.com", "chaturbate.com", "onlyfans.com",
      "brazzers.com", "tnaflix.com", "youjizz.com", "hentaihaven.xxx",
      "motherless.com", "livejasmin.com", "stripchat.com", "9anime.to"
    ],
    keywords: ["porn", "xvideos", "xnxx", "xhamster", "hentai", "camgirl", "camsex", "escort"]
  },
  gambling: {
    domains: [
      "bet365.com", "pokerstars.com", "draftkings.com", "fanduel.com",
      "bovada.lv", "888casino.com", "betway.com", "williamhill.com",
      "pointsbet.com", "partypoker.com", "unibet.com", "betfair.com",
      "888poker.com", "stake.com", "bwin.com"
    ],
    keywords: ["casino", "poker", "sportsbook", "gambl", "betting", "slots"]
  }
};

// Optional categories the user can toggle on/off freely (or lock with a timer).
const CATEGORIES = {
  socialMedia: {
    label: "Social Media",
    domains: [
      "facebook.com", "instagram.com", "twitter.com", "x.com", "tiktok.com",
      "reddit.com", "snapchat.com", "pinterest.com", "threads.net", "tumblr.com"
    ]
  },
  video: {
    label: "Video & Streaming",
    domains: [
      "youtube.com", "netflix.com", "twitch.tv", "hulu.com", "primevideo.com",
      "disneyplus.com", "dailymotion.com"
    ]
  },
  gaming: {
    label: "Gaming",
    domains: [
      "store.steampowered.com", "epicgames.com", "roblox.com", "miniclip.com",
      "poki.com", "chess.com", "ea.com"
    ]
  },
  shopping: {
    label: "Shopping",
    domains: [
      "amazon.com", "ebay.com", "aliexpress.com", "etsy.com", "shein.com",
      "temu.com"
    ]
  },
  news: {
    label: "News",
    domains: [
      "cnn.com", "bbc.com", "foxnews.com", "nytimes.com", "reddit.com/r/news"
    ]
  }
};

if (typeof module !== "undefined") {
  module.exports = { ALWAYS_BLOCKED, CATEGORIES };
}
