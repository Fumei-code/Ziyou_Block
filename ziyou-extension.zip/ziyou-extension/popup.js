const DEFAULTS = { customBlocks: [], categoriesOn: {}, categoryLockUntil: {}, videoCount: 4 };

function fmtRemaining(ms) {
  if (ms <= 0) return "unlocked";
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  if (h > 0) return `${h}h ${m}m left`;
  return `${m}m left`;
}

async function getState() {
  const stored = await chrome.storage.local.get(Object.keys(DEFAULTS));
  return { ...DEFAULTS, ...stored };
}

async function setState(partial) {
  await chrome.storage.local.set(partial);
}

function makeId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

async function renderCustomList() {
  const state = await getState();
  const list = document.getElementById("custom-list");
  const empty = document.getElementById("custom-empty");
  list.innerHTML = "";

  if (state.customBlocks.length === 0) {
    empty.hidden = false;
    return;
  }
  empty.hidden = true;

  const now = Date.now();
  for (const entry of state.customBlocks) {
    const li = document.createElement("li");
    li.className = "list-item";

    const nameSpan = document.createElement("span");
    nameSpan.className = "name";
    nameSpan.textContent = entry.pattern;
    nameSpan.title = entry.pattern;

    const right = document.createElement("div");
    right.style.display = "flex";
    right.style.alignItems = "center";
    right.style.gap = "6px";

    const locked = entry.lockUntil && entry.lockUntil > now;
    if (locked) {
      const status = document.createElement("span");
      status.className = "status";
      status.textContent = fmtRemaining(entry.lockUntil - now);
      right.appendChild(status);
    }

    const removeBtn = document.createElement("button");
    removeBtn.className = "remove-btn";
    removeBtn.textContent = "Remove";
    removeBtn.disabled = locked;
    removeBtn.title = locked ? "Locked until the timer runs out" : "Remove this block";
    removeBtn.addEventListener("click", async () => {
      const s = await getState();
      s.customBlocks = s.customBlocks.filter((e) => e.id !== entry.id);
      await setState({ customBlocks: s.customBlocks });
      renderCustomList();
    });
    right.appendChild(removeBtn);

    li.appendChild(nameSpan);
    li.appendChild(right);
    list.appendChild(li);
  }
}

async function renderCategories() {
  const state = await getState();
  const list = document.getElementById("category-list");
  list.innerHTML = "";
  const now = Date.now();

  for (const [key, def] of Object.entries(CATEGORIES)) {
    const li = document.createElement("li");
    li.className = "category-item";

    const left = document.createElement("div");
    left.className = "category-left";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = !!state.categoriesOn[key];
    const lockUntil = state.categoryLockUntil[key] || null;
    const locked = lockUntil && lockUntil > now;
    checkbox.disabled = locked; // can't turn off (or on) while locked

    const label = document.createElement("span");
    label.textContent = def.label;

    checkbox.addEventListener("change", async () => {
      const s = await getState();
      s.categoriesOn[key] = checkbox.checked;
      await setState({ categoriesOn: s.categoriesOn });
      renderCategories();
    });

    left.appendChild(checkbox);
    left.appendChild(label);

    const right = document.createElement("div");
    right.style.display = "flex";
    right.style.alignItems = "center";
    right.style.gap = "6px";

    if (locked) {
      const status = document.createElement("span");
      status.className = "status";
      status.textContent = fmtRemaining(lockUntil - now);
      right.appendChild(status);
    } else if (checkbox.checked) {
      const lockBtn = document.createElement("button");
      lockBtn.className = "lock-icon-btn";
      lockBtn.textContent = "Lock";
      lockBtn.title = "Lock this category so you can't turn it off early";
      lockBtn.addEventListener("click", async () => {
        const input = window.prompt(
          `Lock "${def.label}" for how many minutes? (e.g. 60)`,
          "60"
        );
        const minutes = parseInt(input, 10);
        if (!minutes || minutes <= 0) return;
        const s = await getState();
        s.categoryLockUntil[key] = Date.now() + minutes * 60000;
        await setState({ categoryLockUntil: s.categoryLockUntil });
        renderCategories();
      });
      right.appendChild(lockBtn);
    }

    li.appendChild(left);
    li.appendChild(right);
    list.appendChild(li);
  }
}

document.getElementById("lock-checkbox").addEventListener("change", (e) => {
  document.getElementById("duration-row").hidden = !e.target.checked;
});

document.getElementById("add-btn").addEventListener("click", async () => {
  const raw = document.getElementById("site-input").value.trim();
  if (!raw) return;

  const locking = document.getElementById("lock-checkbox").checked;
  let lockUntil = null;
  if (locking) {
    const hours = parseInt(document.getElementById("lock-hours").value, 10) || 0;
    const minutes = parseInt(document.getElementById("lock-minutes").value, 10) || 0;
    const totalMs = (hours * 3600 + minutes * 60) * 1000;
    if (totalMs <= 0) {
      alert("Set a duration greater than 0 if you want to lock this site.");
      return;
    }
    lockUntil = Date.now() + totalMs;
  }

  const state = await getState();
  state.customBlocks.push({ id: makeId(), pattern: raw, addedAt: Date.now(), lockUntil });
  await setState({ customBlocks: state.customBlocks });

  document.getElementById("site-input").value = "";
  document.getElementById("lock-checkbox").checked = false;
  document.getElementById("duration-row").hidden = true;
  renderCustomList();
});

document.getElementById("video-count").addEventListener("change", async (e) => {
  const n = Math.max(1, parseInt(e.target.value, 10) || 4);
  await setState({ videoCount: n });
});

async function init() {
  const state = await getState();
  document.getElementById("video-count").value = state.videoCount || 4;
  renderCustomList();
  renderCategories();
}

init();

// Keep countdowns fresh while the popup is open.
setInterval(() => {
  renderCustomList();
  renderCategories();
}, 1000);
