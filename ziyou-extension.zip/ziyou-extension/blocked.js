(function () {
  const params = new URLSearchParams(location.search);
  const site = params.get("site") || "";
  const reason = params.get("reason") || "";
  const unlockAt = parseInt(params.get("unlockAt") || "", 10);

  document.getElementById("site-line").textContent = site
    ? `${site} — ${reason || "blocked"}`
    : (reason || "blocked");

  // Pick a random quote, different from last time if possible, so back-to-back
  // attempts on the same site don't show the exact same line twice in a row.
  const lastQuote = sessionStorage.getItem("ziyou-last-quote");
  let pool = QUOTES;
  if (QUOTES.length > 1 && lastQuote) {
    pool = QUOTES.filter((q) => q.text !== lastQuote);
  }
  const chosen = pool[Math.floor(Math.random() * pool.length)];
  sessionStorage.setItem("ziyou-last-quote", chosen.text);

  document.getElementById("quote-text").textContent = chosen.text;
  document.getElementById("quote-tag").textContent = chosen.tag || "";

  // Pick a random background video out of however many the user has supplied.
  chrome.storage.local.get({ videoCount: 4 }, ({ videoCount }) => {
    const n = Math.max(1, videoCount || 4);
    const idx = 1 + Math.floor(Math.random() * n);
    const video = document.getElementById("bg-video");
    const src = chrome.runtime.getURL(`media/vid${idx}.mp4`);
    video.src = src;
    video.play().catch(() => {
      // Autoplay can be blocked before any user gesture on the very first
      // load of the extension; a silent muted loop almost never hits this,
      // but fail quietly rather than showing an error to the user.
    });
  });

  // Countdown, if this block is time-locked.
  if (unlockAt && !isNaN(unlockAt)) {
    const line = document.getElementById("unlock-line");
    const span = document.getElementById("countdown");
    line.hidden = false;

    function tick() {
      const remaining = unlockAt - Date.now();
      if (remaining <= 0) {
        span.textContent = "00:00:00";
        return;
      }
      const h = Math.floor(remaining / 3600000);
      const m = Math.floor((remaining % 3600000) / 60000);
      const s = Math.floor((remaining % 60000) / 1000);
      span.textContent = [h, m, s].map((x) => String(x).padStart(2, "0")).join(":");
      requestAnimationFrame(() => setTimeout(tick, 250));
    }
    tick();
  }

  document.getElementById("back-btn").addEventListener("click", () => {
    if (history.length > 1) {
      history.back();
    } else {
      window.close();
    }
  });
})();
