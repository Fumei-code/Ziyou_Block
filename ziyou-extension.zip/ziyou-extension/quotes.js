// quotes.js — shown on the block page, one picked at random on every load.
// Phrasing below is original/paraphrased (not copied from any single translation),
// so it's safe to ship and easy for you to edit to taste.

const QUOTES = [
  { text: "Do it now. Don't leave it for a version of you that regrets today.", tag: "" },
  { text: "The time is passing whether you use it or not. Choose to use it.", tag: "" },
  { text: "You won't remember this scroll in a week. You'll remember what you built instead.", tag: "" },
  { text: "Discipline is choosing between what you want now and what you want most.", tag: "" },
  { text: "Every minute spent here is a minute you can't ask for back.", tag: "" },
  { text: "Future you is watching. Make this one count.", tag: "" },
  { text: "Small wasted minutes become wasted years. Close this tab.", tag: "" },
  { text: "By time — truly, humankind is in loss, except those who believe, do good, and hold to truth and patience.", tag: "Surah Al-'Asr (103:1-3)" },
  { text: "Take benefit of five before five: your youth before your old age, your health before your sickness, your wealth before your poverty, your free time before your work, and your life before your death.", tag: "Hadith — narrated in Al-Hakim / Bayhaqi" },
  { text: "Two blessings many people lose out on: good health, and free time.", tag: "Hadith — Sahih al-Bukhari" },
  { text: "Whoever's two days are equal, he is at a loss — make today better than yesterday.", tag: "Attributed narration, common reminder" },
  { text: "Actions are judged by intentions. Ask what this moment is really for.", tag: "Hadith — Sahih al-Bukhari" },
  { text: "Verily, with hardship comes ease. This distraction won't make the ease come faster.", tag: "Surah Ash-Sharh (94:6)" },
  { text: "The one who remembers what they came here to do is stronger than the one who forgot.", tag: "" },
  { text: "This site will still exist later. This hour of your life will not.", tag: "" },
  { text: "You already know what you should be doing right now. Go do that.", tag: "" },
  { text: "A closed tab now is worth more than an open one you'll regret tonight.", tag: "" },
  { text: "None of us know how much time we have. Spend this bit of it on purpose.", tag: "" }
];

if (typeof module !== "undefined") {
  module.exports = { QUOTES };
}
